import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
// I use department and student superclass and undergraduate and graduate subclass
abstract class Department {
    protected String name;

    public Department(String name) {
        this.name = name;

    }

    public abstract void registerStudent(Student student);
}

class Student {
    protected String name;
    protected int uid;

    public Student(String name, int uid) {
        this.name = name;
        this.uid = uid;
    }
}

class Undergraduate extends Department {
    private final List<Student> students;

    public Undergraduate(String name) {
        super(name);
        students = new ArrayList<>();
    }

    @Override
    public void registerStudent(Student student) {
        students.add(student);
        System.out.println("Undergraduate student " + student.name + " registered for " + name + " department.");
    }
}

class Graduate extends Department {
    private final List<Student> students;

    public Graduate(String name) {
        super(name);
        students = new ArrayList<>();
    }

    @Override
    public void registerStudent(Student student) {
        students.add(student);
        System.out.println("Graduate student " + student.name + " registered for " + name + " department.");
    }
}

public class Main {
    public static void main(String[] args) {
        List<String> studentList = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print("Enter student name (or 'continue' to exit): ");
            String studentName = scanner.nextLine();

            if (studentName.equalsIgnoreCase("continue")) {
                break;
            }

            try {
                studentList.add(studentName);
                System.out.println("Student registered successfully!");
            } catch (Exception e) {
                System.out.println("An error occurred while registering the student. Please try again.");
            }
        }

        System.out.print("Enter student name: ");
        String name = scanner.nextLine();

        System.out.print("Enter student UID: ");
        int uid = scanner.nextInt();

        System.out.print("Enter department name (Undergraduate/Graduate): ");
        String department = scanner.next();

        System.out.println("Welcome to Haramaya Student Registration System!");
        System.out.println("Please complete the registration process.");
        Student student = new Student(name, uid);
    }

    }

